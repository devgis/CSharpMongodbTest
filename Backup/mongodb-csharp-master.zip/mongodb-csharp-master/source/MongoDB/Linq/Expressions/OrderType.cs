﻿namespace MongoDB.Linq.Expressions
{
    internal enum OrderType
    {
        Ascending,
        Descending
    }
}
